package step;

import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import hooks.SelBase;
import pages.HomePage;
import pages.LoginPage;

public class LoginStep extends SelBase {
	
	
	LoginPage lp;
	HomePage hp;
	
	
	@Given("Enter username as demosalesmanager")
	public void enterUsernameAsDemosalesmanager() {
	   
		lp=new LoginPage(driver);
		lp.enterUsername();
	}

	@Given("Enter password as crmsfa")
	public void enterPasswordAsCrmsfa() throws InterruptedException {
	    lp.enterPassword();
	}

	@When("Click on Login button")
	public void clickOnLoginButton() {
	    lp.clickLogin();
	}

	@Then("Homepage should be displayed")
	public void homepageShouldBeDisplayed() {
	    hp=new HomePage(driver);
	    hp.checkTitle();
	}

}
