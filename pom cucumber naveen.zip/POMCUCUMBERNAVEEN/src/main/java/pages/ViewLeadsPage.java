package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import hooks.SelBase;



public class ViewLeadsPage extends SelBase {
	
	
	public ViewLeadsPage(ChromeDriver driver) {
    	this.driver=driver; 
	}
	
	public EditLeadPage clickEditButton() {
		driver.findElementByLinkText("Edit").click();
		return new EditLeadPage((ChromeDriver) driver);
	}
}
