package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import hooks.SelBase;



public class MyLeadsPage extends SelBase {
	
	public MyLeadsPage(ChromeDriver driver) {
    	this.driver=driver; 
	}
	
	
	public CreateLeadPage clickCrateLead() {
		driver.findElementByLinkText("Create Lead").click();
		return new CreateLeadPage(driver);
	}
	
	public FindLeadsPage clickFindLeads() {
		driver.findElementByLinkText("Find Leads").click();
		return new FindLeadsPage(driver);
	}
}

