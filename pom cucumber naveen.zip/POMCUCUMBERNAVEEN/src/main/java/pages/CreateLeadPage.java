package pages;

import org.openqa.selenium.chrome.ChromeDriver;


import hooks.SelBase;

public class CreateLeadPage extends SelBase {
	
	
	public CreateLeadPage(ChromeDriver driver) {
    	this.driver=driver; 
		
	}

	
	public CreateLeadPage enterCompanyName() {
		driver.findElementById("createLeadForm_companyName").sendKeys("TestLeaf");
		return this;
	}
	
	public CreateLeadPage enterFirstName() {
		
		driver.findElementById("createLeadForm_firstName").sendKeys("Gopi");
		return this;
	}

    public CreateLeadPage enterLastName() {
	
    	driver.findElementById("createLeadForm_lastName").sendKeys("J");
		return this;
	}
	
	
	public void clickSubmitButton() {
		driver.findElementByName("submitButton").click();
		
	}

}