package pages;

import org.openqa.selenium.chrome.ChromeDriver;


import hooks.SelBase;

public class MyHomePage extends SelBase {
	
	
	public MyHomePage(ChromeDriver driver) {
    	this.driver=driver;
	}
	
	
	public MyLeadsPage clickonLeads() {
		driver.findElementByLinkText("Leads").click();
		return new MyLeadsPage(driver);
	}	
}
